from django.shortcuts import render , redirect
from EMSApp.models import Employee
from django.contrib.auth.models import User 
from django.contrib import messages
from django.contrib.auth import authenticate , login ,logout
from django.contrib.auth.decorators import login_required


# Create your views here.


def main(request):
    return render(request, 'masterPage.html')

# @login_required
def home(request):
    employee=Employee.objects.all
    return render(request , 'home.html', {'emp':employee})

# @login_required
def insert(request):
    if request.method=="POST":
        Id=request.POST["empid"]
        name=request.POST["empname"]
        doj=request.POST["doj"]
        salary=request.POST["salary"]
        did=request.POST["did" ]
        age=request.POST["age"]
        country=request.POST["Country"]
        contact=request.POST["contact"]
        print(Id,name)
        obj=Employee(Id,name,doj,salary,did,age,country,contact)
        # obj=obj.__dict__
        obj.save()
        print(doj)
        return redirect('/')
    else:
        return render(request , 'insert.html')

def delete(request,id):
    obj=Employee.objects.filter(empid=id)
    obj.delete()
    return redirect("/home" )
def edit(request , id):
    obj=Employee.objects.filter(empid=id)
    for o in obj:
        name=o.__dict__['empname']
        print(o.__dict__)
    print(name)
    return render(request ,"update.html" ,{'id':id ,'name':name })
def update(request):
    if request.method== "POST":
        id=request.POST["empid"]
        Name=request.POST["empname"]
        
    
    obj=Employee.objects.filter(empid=id).update(empname=Name)
    
    # obj.save()
    return redirect('/')

def base(request):
    if request.method== "POST":
        fname=request.POST["fname"]
        lname=request.POST["lname"]
        email=request.POST["email"]
        user=request.POST["uname"]
        pword=request.POST["pword"]
        user=User.objects.create_user(first_name=fname , last_name=lname , email=email , username=user , password=pword)
        user.save()
        return redirect('/')
    else :
        return render(request , 'base.html')
        
def signin(request):
    
    if request.method== "POST":
        uname=request.POST["uname"]
        pword=request.POST["pword"]
        user = authenticate(request , username=uname, password=pword)
        
        if user is not None:
            login(request, user)
            print('autehentic')
        else:
            print("UserNotFound")
        return redirect("/")
    else :
        return render(request , 'signin.html')



# from django.contrib.auth import logout

def signout(request):
    if request.method=="POST":
        logout(request)
        return redirect('/')
    else:
        return render(request , "signout.html")
    


    # Redirect to a success page 