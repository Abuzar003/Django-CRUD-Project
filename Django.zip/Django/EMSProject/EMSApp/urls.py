from django.urls import path
from  EMSApp import views

urlpatterns = [
    path('', views.main, name='main'),
    path('home', views.home, name='home'),
    path('insert', views.insert , name='insert' ),
    path('delete/<int:id>', views.delete , name='delete' ),
    path('edit/<int:id>', views.edit , name='edit' ),
    path('update', views.update , name='update' ),
    path('base', views.base , name='base' ),
    path('signin' , views.signin , name="signin"),
    path('signout' , views.signout , name="signout")
    # ,
    # path('signout' , views.signout , name="signout")
]









